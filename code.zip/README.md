# Back end for My Thesis

To run this

```
docker compose build
docker compose up
```
